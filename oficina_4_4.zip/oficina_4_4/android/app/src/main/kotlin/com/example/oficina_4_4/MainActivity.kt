package com.example.oficina_4_4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
